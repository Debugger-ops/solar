// Central UI/simulation state, kept in one small zustand store so any
// component (the canvas, the HUD, a future feature) can read or drive it
// without prop-drilling. Add new controls here as the project grows.
//
// `persist` remembers speed/orbits/labels/running across visits via
// localStorage (key: "orrery-preferences") - `selected` and
// `controlsCollapsed` are deliberately left out, since a reload landing on
// last session's zoomed-in moon (or a collapsed panel on a now-wide window)
// would be more confusing than helpful.
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useOrreryStore = create(
  persist(
    (set) => ({
      daysPerSecond: 20,
      running: true,
      showOrbits: true,
      showLabels: true,
      selected: 'Sun', // name of the selected body, or null
      controlsCollapsed: typeof window !== 'undefined' && window.innerWidth < 640,

      setSpeed: (daysPerSecond) => set({ daysPerSecond }),
      toggleRunning: () => set((s) => ({ running: !s.running })),
      setRunning: (running) => set({ running }),
      toggleOrbits: () => set((s) => ({ showOrbits: !s.showOrbits })),
      toggleLabels: () => set((s) => ({ showLabels: !s.showLabels })),
      select: (name) => set({ selected: name }),
      toggleControlsCollapsed: () => set((s) => ({ controlsCollapsed: !s.controlsCollapsed })),
    }),
    {
      name: 'orrery-preferences',
      partialize: (s) => ({
        daysPerSecond: s.daysPerSecond,
        running: s.running,
        showOrbits: s.showOrbits,
        showLabels: s.showLabels,
      }),
    }
  )
)
