// A plain (non-reactive) registry mapping a body's name to the THREE.Object3D
// that holds its live position. Planets/moons update their own position
// imperatively every frame (see Planet.jsx's useFrame) rather than through
// React state, so CameraRig reads positions straight from these refs instead
// of subscribing to anything - keeps the animation loop entirely outside
// React's render cycle, which is what makes it fast.
export const bodyRefs = {}

export function registerBody(name, ref) {
  bodyRefs[name] = ref
  return () => {
    if (bodyRefs[name] === ref) delete bodyRefs[name]
  }
}
