import * as THREE from 'three'

// World-space radius that would appear as roughly `pixels` on screen for a
// perspective camera sitting `distance` away. Used to keep each body's
// invisible click/tap target a comfortable, constant screen size no matter
// how far the camera has zoomed out - without this, a planet's actual
// hit-sphere (sized in world units) shrinks to just a couple of screen
// pixels at the default whole-system overview, and clicks on it miss more
// often than they land.
export function screenSpaceRadius(camera, viewportHeight, distance, pixels) {
  const vFovRad = THREE.MathUtils.degToRad(camera.fov)
  const worldHeightAtDistance = 2 * Math.tan(vFovRad / 2) * distance
  const worldPerPixel = worldHeightAtDistance / viewportHeight
  return worldPerPixel * pixels
}

// Comfortable radius, in screen pixels, for a body's tap/click target.
export const TAP_TARGET_PX = 14
