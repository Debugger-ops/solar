import { Suspense, useRef } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Stars } from '@react-three/drei'
import Sun from './Sun'
import Planet from './Planet'
import Comet from './Comet'
import AsteroidBelt from './AsteroidBelt'
import CameraRig from './CameraRig'
import { PLANETS, SUN, COMET } from '../data/planets'
import { useOrreryStore } from '../store/useOrreryStore'

export default function Scene() {
  const select = useOrreryStore((s) => s.select)
  const controlsRef = useRef()

  return (
    <Canvas
      camera={{ position: [-30, 42, 100], fov: 50, near: 0.1, far: 700 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onPointerMissed={() => select(null)}
    >
      <color attach="background" args={['#04050a']} />
      <fogExp2 attach="fog" args={['#04050a', 0.0025]} />

      <ambientLight color={0x223047} intensity={0.55} />
      <Stars radius={220} depth={90} count={2600} factor={2} saturation={0} fade speed={0.3} />

      {/* Earth's real image textures (useTexture, in BodySurface/EarthClouds)
          load asynchronously and need a Suspense boundary above them - R3F
          requires this for any useLoader/useTexture usage, so it wraps
          everything here rather than just Earth. */}
      <Suspense fallback={null}>
        <Sun radius={SUN.radius} />
        <AsteroidBelt />
        <Comet data={COMET} />

        {PLANETS.map((planet) => (
          <Planet key={planet.name} data={planet} />
        ))}
      </Suspense>

      <OrbitControls
        ref={controlsRef}
        enableDamping
        dampingFactor={0.07}
        minDistance={3}
        maxDistance={260}
        enablePan={false}
        target={[0, 0, 0]}
      />
      <CameraRig controlsRef={controlsRef} />
    </Canvas>
  )
}
