import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import BodySurface from './BodySurface'
import OrbitPath from './OrbitPath'
import { useOrreryStore } from '../store/useOrreryStore'
import { registerBody } from '../three/bodyRefs'
import { screenSpaceRadius } from '../three/screenSpaceRadius'

// A moon: orbits inside its planet's holder group, so it automatically
// travels with the planet around the sun. Otherwise identical in spirit to
// Planet.jsx - a holder group for the orbit position, a spinning mesh
// inside it - which is the pattern to copy for any further nested body
// (a spacecraft orbiting a moon, say).
export default function Moon({ data, parentSpeedFactor = 1 }) {
  const holderRef = useRef()
  const meshRef = useRef()
  const hitRef = useRef()
  const angleRef = useRef(Math.random() * Math.PI * 2)
  const worldPos = useMemo(() => new THREE.Vector3(), [])

  const { camera, size } = useThree()
  const daysPerSecond = useOrreryStore((s) => s.daysPerSecond)
  const running = useOrreryStore((s) => s.running)
  const showOrbits = useOrreryStore((s) => s.showOrbits)
  const showLabels = useOrreryStore((s) => s.showLabels)
  const select = useOrreryStore((s) => s.select)
  const selected = useOrreryStore((s) => s.selected)

  const a = data.distanceDisplay
  // Cap how far the enlarged hit target can reach: never past halfway to the
  // parent planet's center, or a moon on a tight orbit (Earth's Moon sits
  // just 1.7 units out) would swallow clicks meant for the planet itself.
  const maxHitRadius = a * 0.5
  const hitRadius = useMemo(() => Math.min(Math.max(data.radius * 2.2, 0.5), maxHitRadius), [data.radius, maxHitRadius])

  useEffect(() => registerBody(data.name, holderRef), [data.name])

  useFrame((_, delta) => {
    if (running) {
      angleRef.current += ((delta * daysPerSecond) / data.periodDays) * Math.PI * 2
    }
    const x = Math.cos(angleRef.current) * a
    const z = Math.sin(angleRef.current) * a
    holderRef.current.position.set(x, 0, z)
    if (meshRef.current) meshRef.current.rotation.y += delta * data.spin

    // Smaller on-screen target than a planet's (10px vs 14px) - moons of
    // the same planet sit close together on screen at the default zoom, so
    // a bigger target would make them overlap and steal each other's clicks.
    if (hitRef.current) {
      holderRef.current.getWorldPosition(worldPos)
      const dist = camera.position.distanceTo(worldPos)
      const onScreen = screenSpaceRadius(camera, size.height, dist, 10)
      hitRef.current.scale.setScalar(Math.min(Math.max(onScreen, hitRadius), maxHitRadius))
    }
  })

  const isSelected = selected === data.name

  return (
    <>
      <OrbitPath a={a} ecc={0} visible={showOrbits} />
      <group ref={holderRef}>
        <mesh
          ref={meshRef}
          onClick={(e) => {
            e.stopPropagation()
            select(data.name)
          }}
        >
          <sphereGeometry args={[data.radius, 24, 24]} />
          <BodySurface data={data} />
        </mesh>

        {/* invisible (but still raycastable) hit target, kept a constant
            on-screen size every frame (see useFrame above) */}
        <mesh
          ref={hitRef}
          visible={false}
          onClick={(e) => {
            e.stopPropagation()
            select(data.name)
          }}
        >
          <sphereGeometry args={[1, 8, 8]} />
          <meshBasicMaterial />
        </mesh>

        {showLabels && (
          <Html position={[0, data.radius * 1.8 + 0.15, 0]} center distanceFactor={26} occlude>
            <div className={`planet-label moon-label${isSelected ? ' active' : ''}`}>{data.name}</div>
          </Html>
        )}
      </group>
    </>
  )
}
