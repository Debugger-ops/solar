import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { sunTexture, glowTexture } from '../three/textures'
import { useOrreryStore } from '../store/useOrreryStore'
import { registerBody } from '../three/bodyRefs'
import { screenSpaceRadius, TAP_TARGET_PX } from '../three/screenSpaceRadius'

export default function Sun({ radius = 6 }) {
  const groupRef = useRef()
  const meshRef = useRef()
  const hitRef = useRef()
  const texture = useMemo(() => sunTexture(), [])
  const glow = useMemo(() => glowTexture(0xffcf6b), [])
  const select = useOrreryStore((s) => s.select)
  const { camera, size } = useThree()

  useEffect(() => registerBody('Sun', groupRef), [])

  useFrame((_, delta) => {
    if (meshRef.current) meshRef.current.rotation.y += delta * 0.05
    if (hitRef.current) {
      const dist = camera.position.distanceTo(groupRef.current.position)
      const onScreen = screenSpaceRadius(camera, size.height, dist, TAP_TARGET_PX)
      hitRef.current.scale.setScalar(Math.max(onScreen, radius))
    }
  })

  return (
    <group ref={groupRef}>
      <pointLight color={0xfff2d6} intensity={6.5} decay={0} />
      <mesh ref={meshRef} onClick={(e) => { e.stopPropagation(); select('Sun') }}>
        <sphereGeometry args={[radius, 48, 48]} />
        <meshBasicMaterial map={texture} />
      </mesh>
      {/* invisible (but still raycastable) hit target, kept a constant
          on-screen size every frame - see useFrame above */}
      <mesh ref={hitRef} visible={false} onClick={(e) => { e.stopPropagation(); select('Sun') }}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshBasicMaterial />
      </mesh>
      <sprite scale={[radius * 4.3, radius * 4.3, 1]}>
        <spriteMaterial map={glow} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
      </sprite>
    </group>
  )
}
