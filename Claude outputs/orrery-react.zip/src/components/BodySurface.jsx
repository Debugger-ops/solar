import { useMemo } from 'react'
import { useTexture } from '@react-three/drei'
import { bandedTexture, earthTexture } from '../three/textures'

// Picks the right <meshStandardMaterial> for a planet or moon: a real image
// texture when `data.textureUrl` is set (Earth, the Moon), otherwise a
// procedural canvas texture, otherwise a flat color. Split into its own
// component (rather than an if/else inside Planet.jsx) so the real-texture
// path can call the `useTexture` hook unconditionally - see the README for
// how to point more bodies at real texture files.
export default function BodySurface({ data }) {
  if (data.textureUrl) return <RealSurface data={data} />
  return <ProceduralSurface data={data} />
}

function RealSurface({ data }) {
  const map = useTexture(data.textureUrl)
  return <meshStandardMaterial map={map} roughness={0.9} metalness={0.05} />
}

function ProceduralSurface({ data }) {
  const texture = useMemo(() => {
    if (data.map === 'earth') return earthTexture()
    if (data.map === 'bands') return bandedTexture(data.color, 0xffffff, 10)
    return null
  }, [data.map, data.color])

  if (texture) return <meshStandardMaterial map={texture} roughness={0.85} metalness={0.05} />
  return <meshStandardMaterial color={data.color} roughness={0.85} metalness={0.05} />
}
