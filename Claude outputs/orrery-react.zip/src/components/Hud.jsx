export default function Hud() {
  return (
    <>
      <div className="hud hud-title">
        <span className="tag">React &middot; react-three-fiber</span>
        <h1>Orrery</h1>
        <p>Eight planets, five moons and Halley's Comet on their real orbital periods and eccentricities. Distances and sizes are compressed to fit the screen.</p>
      </div>
      <div className="hint">drag to orbit &middot; scroll to zoom &middot; tap a body (or search) to fly to it</div>
    </>
  )
}
