import { useEffect, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { useOrreryStore } from '../store/useOrreryStore'
import { bodyRefs } from '../three/bodyRefs'
import { findBody } from '../data/planets'

const FLIGHT_DURATION = 0.8 // seconds
const ORIGIN = new THREE.Vector3(0, 0, 0)
const _worldPos = new THREE.Vector3()

function easeOutQuad(t) {
  return t * (2 - t)
}

// World-space position of a registered body. Uses getWorldPosition (rather
// than reading .position directly) because a moon's holder is nested inside
// its planet's holder, so its local position alone isn't where it actually
// is in the scene.
function currentPositionOf(name) {
  const ref = bodyRefs[name]
  if (!ref?.current) return ORIGIN
  return ref.current.getWorldPosition(_worldPos)
}

// Flies the camera to whatever gets selected (click, search, whatever calls
// useOrreryStore's `select`), preserving the viewing angle the user already
// had and just changing distance to suit the body's size. Once the flight
// finishes, it keeps the camera's offset from the body constant every frame
// (translating camera + target by the body's own motion) so a planet mid-orbit
// doesn't drift out of frame - a small chase-cam, in effect.
export default function CameraRig({ controlsRef }) {
  const { camera } = useThree()
  const selected = useOrreryStore((s) => s.selected)

  const flying = useRef(false)
  const flightElapsed = useRef(0)
  const flightFromPos = useRef(new THREE.Vector3())
  const flightFromTarget = useRef(new THREE.Vector3())
  const flightToPos = useRef(new THREE.Vector3())
  const flightToTarget = useRef(new THREE.Vector3())
  const prevBodyPos = useRef(new THREE.Vector3())
  const hasFlownOnce = useRef(false)

  useEffect(() => {
    const controls = controlsRef.current
    if (!controls) return

    // Don't fly on the very first render just because `selected` defaults to
    // 'Sun' - that would yank the camera in before the user has done
    // anything. Only actual selection changes (a click, a search) fly.
    if (!hasFlownOnce.current) {
      hasFlownOnce.current = true
      prevBodyPos.current.copy(currentPositionOf(selected))
      return
    }

    // Clicking empty space (or pressing Escape-equivalent) clears the
    // selection so the info card closes - it shouldn't also yank the camera
    // back to the origin. Just stop any tracking and leave the view where
    // the user left it.
    if (!selected) {
      flying.current = false
      return
    }

    const bodyPos = currentPositionOf(selected).clone()
    const body = findBody(selected)
    const radius = body?.data?.radius ?? null

    const offsetDir = camera.position.clone().sub(controls.target)
    if (offsetDir.lengthSq() < 1e-6) offsetDir.set(0.3, 0.5, 1)
    offsetDir.normalize()

    const distance = radius ? THREE.MathUtils.clamp(radius * 9, 7, 46) : 90

    flightFromPos.current.copy(camera.position)
    flightFromTarget.current.copy(controls.target)
    flightToTarget.current.copy(bodyPos)
    flightToPos.current.copy(bodyPos).addScaledVector(offsetDir, distance)
    flightElapsed.current = 0
    flying.current = true
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected])

  useFrame((_, delta) => {
    const controls = controlsRef.current
    if (!controls) return

    if (flying.current) {
      flightElapsed.current += delta
      const t = Math.min(1, flightElapsed.current / FLIGHT_DURATION)
      const e = easeOutQuad(t)
      camera.position.lerpVectors(flightFromPos.current, flightToPos.current, e)
      // Bulge the path upward mid-flight so a long trip (say, from a moon on
      // one side of the sun to a comet on the other) arcs over the sun's
      // glow instead of swooping straight through it.
      const arc = Math.sin(Math.PI * t) * Math.max(flightFromPos.current.distanceTo(flightToPos.current) * 0.12, 6)
      camera.position.y += arc
      controls.target.lerpVectors(flightFromTarget.current, flightToTarget.current, e)
      controls.update()
      if (t >= 1) {
        flying.current = false
        prevBodyPos.current.copy(currentPositionOf(selected))
      }
      return
    }

    if (!selected) return // nothing selected - nothing to track

    // Tracking: move camera + target by exactly how far the body moved this
    // frame, so the user's chosen distance/angle is preserved regardless of
    // how fast the selected body orbits.
    const bodyPos = currentPositionOf(selected).clone()
    const stepDelta = bodyPos.clone().sub(prevBodyPos.current)
    if (stepDelta.lengthSq() > 0) {
      camera.position.add(stepDelta)
      controls.target.add(stepDelta)
      controls.update()
    }
    prevBodyPos.current.copy(bodyPos)
  })

  return null
}
