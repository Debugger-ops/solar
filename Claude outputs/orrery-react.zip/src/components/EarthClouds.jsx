import { useTexture } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'

// A second, very slightly larger sphere with the cloud layer as an alpha
// map, spinning a bit faster than the surface underneath it - the standard
// two-sphere trick for a planet with visible weather.
export default function EarthClouds({ radius, cloudsUrl, spin }) {
  const ref = useRef()
  const alphaMap = useTexture(cloudsUrl)

  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.y += delta * spin * 1.4
  })

  return (
    <mesh ref={ref} scale={1.015}>
      <sphereGeometry args={[radius, 32, 32]} />
      <meshStandardMaterial alphaMap={alphaMap} transparent depthWrite={false} color={0xffffff} />
    </mesh>
  )
}
