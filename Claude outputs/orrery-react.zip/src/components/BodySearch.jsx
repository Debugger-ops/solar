import { useState } from 'react'
import { allBodyNames } from '../data/planets'
import { useOrreryStore } from '../store/useOrreryStore'

const NAMES = allBodyNames()

// A tiny search box: type or pick a name (native <datalist> autocomplete,
// so no extra dependency) and it selects that body, which is all
// CameraRig needs to fly the camera there too.
export default function BodySearch() {
  const select = useOrreryStore((s) => s.select)
  const [value, setValue] = useState('')

  function go(raw) {
    const match = NAMES.find((n) => n.toLowerCase() === raw.trim().toLowerCase())
    if (match) {
      select(match)
      setValue('')
    }
  }

  return (
    <form
      className="search"
      onSubmit={(e) => {
        e.preventDefault()
        go(value)
      }}
    >
      <input
        list="orrery-bodies"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Jump to a body..."
        aria-label="Jump to a body"
        autoComplete="off"
      />
      <datalist id="orrery-bodies">
        {NAMES.map((name) => (
          <option value={name} key={name} />
        ))}
      </datalist>
      <button type="submit" className="iconbtn" aria-label="Go to body">
        &#8594;
      </button>
    </form>
  )
}
