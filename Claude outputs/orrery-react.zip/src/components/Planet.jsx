import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import BodySurface from './BodySurface'
import EarthClouds from './EarthClouds'
import Rings from './Rings'
import OrbitPath from './OrbitPath'
import Moon from './Moon'
import { useOrreryStore } from '../store/useOrreryStore'
import { registerBody } from '../three/bodyRefs'
import { screenSpaceRadius, TAP_TARGET_PX } from '../three/screenSpaceRadius'

// One planet: an orbiting holder (the ellipse math lives here), a spinning
// mesh inside it, optional rings and moons, and an HTML label that stays
// anchored to its 3D position. Moons are just more of the same pattern
// nested one level deeper (see Moon.jsx) - that nesting is also the trick
// for a spacecraft orbiting a moon, or a ring of trojans sharing a planet's
// orbit.
export default function Planet({ data }) {
  const holderRef = useRef()
  const meshRef = useRef()
  const hitRef = useRef()
  const angleRef = useRef(Math.random() * Math.PI * 2)
  const worldPos = useMemo(() => new THREE.Vector3(), [])

  const { camera, size } = useThree()
  const daysPerSecond = useOrreryStore((s) => s.daysPerSecond)
  const running = useOrreryStore((s) => s.running)
  const showOrbits = useOrreryStore((s) => s.showOrbits)
  const showLabels = useOrreryStore((s) => s.showLabels)
  const select = useOrreryStore((s) => s.select)
  const selected = useOrreryStore((s) => s.selected)

  const a = data.distanceDisplay
  const b = useMemo(() => a * Math.sqrt(1 - data.ecc * data.ecc), [a, data.ecc])
  const focusOffset = a * data.ecc

  // A planet's enlarged click target must stay well clear of its innermost
  // moon's orbit, or the planet's own hit-sphere geometrically swallows that
  // moon and steals its clicks (this bit Jupiter/Io in testing: Jupiter's
  // plain radius*1.8 hit-sphere reached past Io's whole orbit).
  const nearestMoonDist = useMemo(
    () => (data.moons?.length ? Math.min(...data.moons.map((m) => m.distanceDisplay)) : Infinity),
    [data.moons]
  )
  const maxHitRadius = nearestMoonDist * 0.5
  const hitRadius = useMemo(
    () => Math.min(Math.max(data.radius * 1.8, 0.9), maxHitRadius),
    [data.radius, maxHitRadius]
  )

  useEffect(() => registerBody(data.name, holderRef), [data.name])

  useFrame((_, delta) => {
    if (running) {
      angleRef.current += ((delta * daysPerSecond) / data.periodDays) * Math.PI * 2
    }
    const x = Math.cos(angleRef.current) * a - focusOffset
    const z = Math.sin(angleRef.current) * b
    holderRef.current.position.set(x, 0, z)
    if (meshRef.current) meshRef.current.rotation.y += delta * data.spin

    // Keep the invisible hit target a constant, comfortable size on screen
    // (see screenSpaceRadius) rather than a fixed world-space size - at the
    // default whole-system zoom a fixed-size target shrinks to a couple of
    // screen pixels and clicks miss it more often than they land.
    if (hitRef.current) {
      holderRef.current.getWorldPosition(worldPos)
      const dist = camera.position.distanceTo(worldPos)
      const onScreen = screenSpaceRadius(camera, size.height, dist, TAP_TARGET_PX)
      hitRef.current.scale.setScalar(Math.min(Math.max(onScreen, hitRadius), maxHitRadius))
    }
  })

  const isSelected = selected === data.name

  return (
    <>
      <OrbitPath a={a} ecc={data.ecc} visible={showOrbits} />
      <group ref={holderRef}>
        <mesh
          ref={meshRef}
          rotation={[0, 0, THREE.MathUtils.degToRad(data.tiltDeg)]}
          onClick={(e) => {
            e.stopPropagation()
            select(data.name)
          }}
        >
          <sphereGeometry args={[data.radius, 32, 32]} />
          <BodySurface data={data} />
        </mesh>

        {/* invisible (but still raycastable) hit target, scaled every frame
            in screenSpaceRadius above to a constant on-screen size - so
            planets stay easy to click/tap whether the camera is right next
            to them or looking at the whole system from far away */}
        <mesh
          ref={hitRef}
          visible={false}
          onClick={(e) => {
            e.stopPropagation()
            select(data.name)
          }}
        >
          <sphereGeometry args={[1, 8, 8]} />
          <meshBasicMaterial />
        </mesh>

        {data.cloudsUrl && (
          <group rotation={[0, 0, THREE.MathUtils.degToRad(data.tiltDeg)]}>
            <EarthClouds radius={data.radius} cloudsUrl={data.cloudsUrl} spin={data.spin} />
          </group>
        )}

        {data.rings && (
          <Rings innerRadius={data.radius * 1.4} outerRadius={data.radius * 2.3} tiltDeg={data.tiltDeg} />
        )}

        {(data.moons || []).map((moon) => (
          <Moon key={moon.name} data={moon} />
        ))}

        {showLabels && (
          <Html position={[0, data.radius * 1.6 + 0.3, 0]} center distanceFactor={40} occlude>
            <div className={`planet-label${isSelected ? ' active' : ''}`}>{data.name}</div>
          </Html>
        )}
      </group>
    </>
  )
}
