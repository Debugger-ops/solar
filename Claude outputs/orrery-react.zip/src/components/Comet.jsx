import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import OrbitPath from './OrbitPath'
import { useOrreryStore } from '../store/useOrreryStore'
import { registerBody } from '../three/bodyRefs'
import { screenSpaceRadius, TAP_TARGET_PX } from '../three/screenSpaceRadius'

const TAIL_COUNT = 140

// A comet on a real, highly eccentric orbit (see COMET in data/planets.js).
// Unlike a planet, its distance from the sun swings wildly, so the tail -
// a particle stream pointing away from the sun, always (that's what a real
// comet tail does: solar wind pushes it outward regardless of direction of
// travel) - is recomputed every frame from the comet's current position,
// growing longer and brighter near perihelion.
export default function Comet({ data }) {
  const holderRef = useRef()
  const meshRef = useRef()
  const hitRef = useRef()
  const tailRef = useRef()
  const angleRef = useRef(Math.random() * Math.PI * 2)
  const worldPos = useMemo(() => new THREE.Vector3(), [])

  const { camera, size } = useThree()
  const daysPerSecond = useOrreryStore((s) => s.daysPerSecond)
  const running = useOrreryStore((s) => s.running)
  const showOrbits = useOrreryStore((s) => s.showOrbits)
  const showLabels = useOrreryStore((s) => s.showLabels)
  const select = useOrreryStore((s) => s.select)
  const selected = useOrreryStore((s) => s.selected)

  const a = data.distanceDisplay
  const b = useMemo(() => a * Math.sqrt(1 - data.ecc * data.ecc), [a, data.ecc])
  const focusOffset = a * data.ecc
  const hitRadius = useMemo(() => Math.max(data.radius * 3, 1.2), [data.radius])

  useEffect(() => registerBody(data.name, holderRef), [data.name])

  const tailPositions = useMemo(() => new Float32Array(TAIL_COUNT * 3), [])

  useFrame((_, delta) => {
    if (running) {
      angleRef.current += ((delta * daysPerSecond) / data.periodDays) * Math.PI * 2
    }
    const x = Math.cos(angleRef.current) * a - focusOffset
    const z = Math.sin(angleRef.current) * b
    holderRef.current.position.set(x, 0, z)
    if (meshRef.current) meshRef.current.rotation.y += delta * data.spin

    if (hitRef.current) {
      holderRef.current.getWorldPosition(worldPos)
      const dist = camera.position.distanceTo(worldPos)
      const onScreen = screenSpaceRadius(camera, size.height, dist, TAP_TARGET_PX)
      hitRef.current.scale.setScalar(Math.max(onScreen, hitRadius))
    }

    const r = Math.max(Math.hypot(x, z), 0.001)
    const dirX = x / r
    const dirZ = z / r
    const tailLength = THREE.MathUtils.clamp(46 / r, 1.2, 26)

    const positions = tailRef.current.geometry.attributes.position.array
    for (let i = 0; i < TAIL_COUNT; i++) {
      const t = i / (TAIL_COUNT - 1)
      const jitter = (Math.random() - 0.5) * 0.35 * t
      positions[i * 3] = x + dirX * tailLength * t + jitter
      positions[i * 3 + 1] = (Math.random() - 0.5) * 0.25 * t
      positions[i * 3 + 2] = z + dirZ * tailLength * t + jitter
    }
    tailRef.current.geometry.attributes.position.needsUpdate = true
    tailRef.current.material.opacity = THREE.MathUtils.clamp(1 - r / 50, 0.15, 0.85)
  })

  const isSelected = selected === data.name

  return (
    <>
      <OrbitPath a={a} ecc={data.ecc} visible={showOrbits} />

      <points ref={tailRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={TAIL_COUNT} array={tailPositions} itemSize={3} />
        </bufferGeometry>
        <pointsMaterial
          color={0xbfe4ff}
          size={0.22}
          sizeAttenuation
          transparent
          opacity={0.6}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>

      <group ref={holderRef}>
        <mesh
          ref={meshRef}
          onClick={(e) => {
            e.stopPropagation()
            select(data.name)
          }}
        >
          <sphereGeometry args={[data.radius, 16, 16]} />
          <meshStandardMaterial color={data.color} emissive={data.color} emissiveIntensity={0.15} roughness={0.6} />
        </mesh>

        <mesh
          ref={hitRef}
          visible={false}
          onClick={(e) => {
            e.stopPropagation()
            select(data.name)
          }}
        >
          <sphereGeometry args={[1, 8, 8]} />
          <meshBasicMaterial />
        </mesh>

        {showLabels && (
          <Html position={[0, data.radius * 2 + 0.3, 0]} center distanceFactor={40} occlude>
            <div className={`planet-label${isSelected ? ' active' : ''}`}>{data.name}</div>
          </Html>
        )}
      </group>
    </>
  )
}
