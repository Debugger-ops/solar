import { findBody, factsFor } from '../data/planets'
import { useOrreryStore } from '../store/useOrreryStore'

export default function InfoCard() {
  const selected = useOrreryStore((s) => s.selected)
  const body = findBody(selected)

  if (!body) {
    return (
      <div className="card">
        <p className="hint-inline">Click the sun, a planet, a moon, or the comet to see its numbers.</p>
      </div>
    )
  }

  const { kind, data, parent } = body
  const facts = kind === 'planet' ? factsFor(data) : data.facts
  const swatch = '#' + data.color.toString(16).padStart(6, '0')

  return (
    <div className="card">
      <div className="name">
        <span className="swatch" style={{ background: swatch }} />
        <span>{data.name}</span>
      </div>
      {parent && <p className="parent-line">orbits {parent.name}</p>}
      <dl>
        {facts.map(([k, v]) => (
          <div className="fact" key={k}>
            <dt>{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
      <p className="note">{data.note}</p>
    </div>
  )
}
