// Real relative orbital data for the eight planets (plus a handful of moons
// and Halley's Comet). Distances and radii are compressed (see
// distanceDisplay / radius) so the whole system fits on screen, but periods,
// eccentricities and relative sizes are all accurate.
//
// Want to add a body? Push a new object here — Scene.jsx maps over PLANETS
// automatically, and a planet's own `moons` array is mapped inside
// Planet.jsx the same way. findBody() and factsFor() know how to look up and
// describe anything added this way, so most new bodies need nothing else.

export const SUN = {
  name: 'Sun',
  color: 0xffcf6b,
  radius: 6,
  facts: [
    ['Type', 'G-type star'],
    ['Radius', '109 × Earth'],
    ['Surface temp.', '≈ 5,500°C'],
    ['% of system mass', '99.86%'],
  ],
  note: 'Every planet in the model orbits it on real relative periods - Mercury laps the sun in the time Neptune barely moves.',
}

export const PLANETS = [
  {
    name: 'Mercury',
    color: 0x9c948a,
    distanceAU: 0.39,
    distanceDisplay: 14,
    periodDays: 88,
    ecc: 0.206,
    radius: 0.5,
    tiltDeg: 0.03,
    spin: 1.6,
    earthRadii: 0.38,
    note: 'The fastest and most eccentric orbit of the eight.',
  },
  {
    name: 'Venus',
    color: 0xe8cda2,
    distanceAU: 0.72,
    distanceDisplay: 18,
    periodDays: 224.7,
    ecc: 0.007,
    radius: 0.92,
    tiltDeg: 177.4,
    spin: -0.4,
    earthRadii: 0.95,
    note: "Spins backwards, so slowly that its day outlasts its year.",
  },
  {
    name: 'Earth',
    color: 0x3f7bd0,
    distanceAU: 1.0,
    distanceDisplay: 22,
    periodDays: 365.25,
    ecc: 0.017,
    radius: 0.97,
    tiltDeg: 23.4,
    spin: 2.0,
    earthRadii: 1.0,
    note: 'One orbit here defines the year every other period is measured against.',
    map: 'earth',
    textureUrl: '/textures/earth_daymap.jpg',
    cloudsUrl: '/textures/earth_clouds.png',
    moons: [
      {
        name: 'Moon',
        color: 0xbdb8ae,
        distanceDisplay: 1.7,
        periodDays: 27.3,
        radius: 0.26,
        spin: 0.6,
        textureUrl: '/textures/moon.jpg',
        facts: [
          ['Distance from Earth', '384,400 km'],
          ['Orbital period', '27.3 days'],
          ['Radius', '0.27 × Earth'],
        ],
        note: "Tidally locked - the same face has pointed at Earth for as long as we've watched it.",
      },
    ],
  },
  {
    name: 'Mars',
    color: 0xb5502e,
    distanceAU: 1.52,
    distanceDisplay: 27,
    periodDays: 687,
    ecc: 0.093,
    radius: 0.58,
    tiltDeg: 25.2,
    spin: 1.9,
    earthRadii: 0.53,
    note: "A visible tilt close to Earth's gives it real seasons.",
  },
  {
    name: 'Jupiter',
    color: 0xd8b98a,
    distanceAU: 5.2,
    distanceDisplay: 40,
    periodDays: 4331,
    ecc: 0.049,
    radius: 3.4,
    tiltDeg: 3.1,
    spin: 4.3,
    earthRadii: 11.2,
    note: 'More massive than every other planet combined.',
    map: 'bands',
    moons: [
      {
        name: 'Io',
        color: 0xe6d18c,
        distanceDisplay: 4.3,
        periodDays: 1.77,
        radius: 0.27,
        spin: 0.8,
        facts: [
          ['Distance from Jupiter', '421,700 km'],
          ['Orbital period', '1.8 days'],
        ],
        note: 'The most volcanically active body in the solar system.',
      },
      {
        name: 'Europa',
        color: 0xd9cdb8,
        distanceDisplay: 5.0,
        periodDays: 3.55,
        radius: 0.23,
        spin: 0.7,
        facts: [
          ['Distance from Jupiter', '671,000 km'],
          ['Orbital period', '3.6 days'],
        ],
        note: 'An icy shell likely hides a liquid ocean - a top target in the search for life.',
      },
      {
        name: 'Ganymede',
        color: 0x9c927f,
        distanceDisplay: 5.8,
        periodDays: 7.15,
        radius: 0.39,
        spin: 0.6,
        facts: [
          ['Distance from Jupiter', '1,070,000 km'],
          ['Orbital period', '7.2 days'],
        ],
        note: 'The largest moon in the solar system - bigger than the planet Mercury.',
      },
      {
        name: 'Callisto',
        color: 0x746a5c,
        distanceDisplay: 6.7,
        periodDays: 16.7,
        radius: 0.36,
        spin: 0.5,
        facts: [
          ['Distance from Jupiter', '1,883,000 km'],
          ['Orbital period', '16.7 days'],
        ],
        note: 'One of the most heavily cratered surfaces known - barely changed in billions of years.',
      },
    ],
  },
  {
    name: 'Saturn',
    color: 0xe3c98f,
    distanceAU: 9.58,
    distanceDisplay: 52,
    periodDays: 10747,
    ecc: 0.057,
    radius: 2.9,
    tiltDeg: 26.7,
    spin: 4.1,
    earthRadii: 9.45,
    note: 'Rings are chunks of ice and rock, some no bigger than a grain of sand.',
    map: 'bands',
    rings: true,
    moons: [
      {
        name: 'Titan',
        color: 0xd8a24a,
        distanceDisplay: 8.0,
        periodDays: 15.95,
        radius: 0.38,
        spin: 0.4,
        facts: [
          ['Distance from Saturn', '1,222,000 km'],
          ['Orbital period', '16.0 days'],
        ],
        note: 'The only moon with a thick atmosphere - and lakes of liquid methane on its surface.',
      },
    ],
  },
  {
    name: 'Uranus',
    color: 0x9fd8e0,
    distanceAU: 19.2,
    distanceDisplay: 66,
    periodDays: 30589,
    ecc: 0.046,
    radius: 1.9,
    tiltDeg: 97.8,
    spin: -2.6,
    earthRadii: 4.0,
    note: 'Tipped almost onto its side - it rolls around the sun rather than spinning upright.',
  },
  {
    name: 'Neptune',
    color: 0x3b5bdb,
    distanceAU: 30.05,
    distanceDisplay: 80,
    periodDays: 59800,
    ecc: 0.011,
    radius: 1.85,
    tiltDeg: 28.3,
    spin: 2.4,
    earthRadii: 3.88,
    note: 'One orbit takes 165 Earth years - it has completed one since its 1846 discovery.',
  },
]

// Halley's Comet: real semi-major axis and eccentricity, so its perihelion
// (~0.59 AU, just inside Venus) and aphelion (~35 AU, past Neptune) land in
// the right places. Its real orbit is tilted ~162° to the planets' (it loops
// backward); this model flattens it onto the same plane for clarity.
export const COMET = {
  name: "Halley's Comet",
  color: 0xcfd6dd,
  distanceAU: 17.8,
  distanceDisplay: 58,
  periodDays: 27750,
  ecc: 0.967,
  radius: 0.22,
  spin: 0.3,
  facts: [
    ['Perihelion', '0.59 AU (inside Venus)'],
    ['Aphelion', '35.1 AU (past Neptune)'],
    ['Orbital period', '~76 years'],
  ],
  note: 'Last seen from Earth in 1986; due back around 2061. Shown flattened onto the ecliptic - its real orbit runs backward at a steep tilt.',
}

export function factsFor(planet) {
  const years = planet.periodDays / 365.25
  return [
    ['Distance from sun', `${planet.distanceAU} AU`],
    ['Orbital period', years >= 1 ? `${years.toFixed(1)} years` : `${planet.periodDays.toFixed(0)} days`],
    ['Orbit eccentricity', planet.ecc.toFixed(3)],
    ['Radius', `${planet.earthRadii.toFixed(2)} × Earth`],
  ]
}

// Flat lookup across the sun, planets, and moons, used by InfoCard, the
// jump-to-body search, and the camera rig. Returns null if nothing matches.
export function findBody(name) {
  if (!name) return null
  if (name === SUN.name) return { kind: 'sun', data: SUN }
  if (name === COMET.name) return { kind: 'comet', data: COMET }
  for (const planet of PLANETS) {
    if (planet.name === name) return { kind: 'planet', data: planet }
    for (const moon of planet.moons || []) {
      if (moon.name === name) return { kind: 'moon', data: moon, parent: planet }
    }
  }
  return null
}

// Every selectable name, in display order, for the jump-to-body search.
export function allBodyNames() {
  const names = [SUN.name]
  for (const planet of PLANETS) {
    names.push(planet.name)
    for (const moon of planet.moons || []) names.push(moon.name)
  }
  names.push(COMET.name)
  return names
}
