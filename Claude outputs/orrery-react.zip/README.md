# Orrery

A scaled 3D solar system, built with React + [react-three-fiber](https://docs.pmnd.rs/react-three-fiber) (Three.js) and [drei](https://github.com/pmndrs/drei), scaffolded with Vite.

Real orbital periods and eccentricities drive the animation; distances and planet sizes are compressed so the whole system fits on screen. Click any body — a planet, a moon, the sun, or Halley's Comet — or use the search box to fly the camera to it and see its numbers (distance, period, eccentricity, relative size). Your speed/orbit/label settings are remembered between visits (localStorage).

## Setup

Requires Node 18+.

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (typically `http://localhost:5173`).

Other scripts:

```bash
npm run build     # production build to dist/
npm run preview   # serve the production build locally
npm run lint      # oxlint
```

`node_modules` isn't included in this download — `npm install` regenerates it from `package.json`, which is the normal way JS/React projects are shared (node_modules is large, platform-specific, and fully reproducible from the lockfile-less `package.json` here; run `npm install` once and you're set).

## Project structure

```
src/
  data/planets.js         Real orbital data: sun, 8 planets (some with moons), Halley's Comet.
                          findBody()/allBodyNames() power the info card and search.
  three/textures.js        Procedural canvas textures (banded gas giants, Saturn's rings, sun, glow)
  three/bodyRefs.js         Registry mapping a body's name -> its live Object3D ref, so the camera
                            rig and other components can find any body's current position
  store/useOrreryStore.js  Zustand store (with `persist`): speed, play/pause, orbit/label visibility,
                          selected body, controls-collapsed. Speed/orbits/labels survive a reload.
  components/
    Scene.jsx              The <Canvas> — camera, lights, starfield, OrbitControls, CameraRig,
                          wraps everything in <Suspense> for the real-texture loads
    CameraRig.jsx          Flies the camera to whatever gets selected, then chase-cams it
    Sun.jsx                Sun mesh + point light + glow sprite
    Planet.jsx             One orbiting, spinning planet + label + optional rings + moons
    Moon.jsx                A moon orbiting inside its parent planet's group
    Comet.jsx               Halley's Comet: elliptical orbit + a dynamic particle tail
    BodySurface.jsx         Real image texture (Earth) vs procedural texture (everything else)
    EarthClouds.jsx          Earth's semi-transparent, independently-spinning cloud layer
    Rings.jsx               Saturn's ring geometry/material
    OrbitPath.jsx            The elliptical orbit line for one body
    AsteroidBelt.jsx         Point cloud between Mars and Jupiter
    Hud.jsx                  Title/description overlay
    InfoCard.jsx             Bottom-left data card for the selected body (planet, moon, sun or comet)
    BodySearch.jsx           Jump-to-body text input with autocomplete
    ControlsPanel.jsx       Bottom-right panel: search, speed/play/orbit/label controls, collapses
                          to a FAB button on small screens
  App.jsx / App.css        Layout and all styling
public/textures/           Real image textures for Earth (day map + clouds) and the Moon
```

## Extending it

A few common additions, and where they'd go:

- **Add a body** (a ninth planet, a dwarf planet, a moon): add an entry to `PLANETS` (or a `moons` array on an existing planet) in `src/data/planets.js`. `Scene.jsx`/`Planet.jsx` map over these automatically, and `findBody()`/`allBodyNames()` pick it up for the info card and search with no other changes.
- **New controls**: add state + an action to `useOrreryStore.js`, then read it wherever it's needed — no prop drilling required. Add the field to the `persist` middleware's `partialize` list if it should survive a reload.
- **More real textures**: give a body a `textureUrl` (and `cloudsUrl` for a cloud layer) in `planets.js` — `BodySurface.jsx` already prefers a real texture over the procedural one whenever `textureUrl` is set, via drei's `useTexture`.
- **Camera behavior**: all fly-to/chase-cam logic lives in `CameraRig.jsx`, driven purely by `useOrreryStore`'s `selected` value — anything that calls `select(name)` (a click, the search box, a future "next body" button) gets a flight for free.
- **Comets, spacecraft trajectories**: `Comet.jsx` is a good template — real orbital elements in, elliptical position math out, plus a tail. A second comet is just another object shaped like `COMET` in `planets.js` and another `<Comet data={...} />` in `Scene.jsx`.

## Notes

- Gas-giant bands, Saturn's rings, the sun's surface and its glow are generated at runtime with `<canvas>` (see `three/textures.js`); Earth and the Moon use real photographic textures from three.js's own example assets (`public/textures/`, MIT-licensed).
- Distances (`distanceDisplay`) and sizes (`radius`) are compressed for visibility; `distanceAU`/`earthRadii` (or the facts arrays, for moons/the comet) hold the real numbers, shown in the info card.
- Preferences (speed, play/pause, orbit paths, labels) persist to `localStorage` under the key `orrery-preferences`; the currently-selected body and panel-collapsed state intentionally do not, so every visit starts at the Sun.
- The scene renders in a single dark theme by design (deep space doesn't have a sensible light mode).
